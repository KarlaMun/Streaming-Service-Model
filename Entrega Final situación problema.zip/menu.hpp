#ifndef MENU_H
#define MENU_H

#include <bits/stdc++.h>
using namespace std;

// Muestra el menú de opciones
int printMenu(); 


#endif //MENU_H